#include "Puerta_NOT.hpp"
#include <iterator>

bool circuito::Puerta_NOT::actualizar()  {
    if (out_pin.calculado) return true;
    out_pin.calculado = true;
    out_pin.valor = !get_in_pin(0).valor;
    return out_pin.calculado;
}
