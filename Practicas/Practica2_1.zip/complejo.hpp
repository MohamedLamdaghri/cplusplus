#ifndef COMPLEJO_HPP_INCLUDED
#define COMPLEJO_HPP_INCLUDED

namespace complejos {

    class Complejo {
        double real, img;

    public:

        Complejo (const double v1=0.0, const double v2=0.0 /*, const FormatoNumComplejo formato = FormatoNumComplejo::realImg*/);
        Complejo operator+ (const Complejo &r);
        std::string to_string () const;

    };

    std::ostream& operator<< (std::ostream &os, const Complejo &c);
    std::istream& operator>> (std::istream &is, Complejo &c);
}
#endif // COMPLEJO_HPP_INCLUDED
